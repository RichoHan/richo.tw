# Scriptor (Modified)

Scriptor is a minimal, clean, modern & responsive Ghost theme for writers, originally forked from [JustGoodThemes/Scriptor](https://github.com/JustGoodThemes/Scriptor).

## Copyright & License
MIT

> Copyright for portions of project [Scriptor](https://github.com/RichoHan/Scriptor) are held by [JustGoodThemes, 2018] as part of project [Scriptor](https://github.com/JustGoodThemes/Scriptor). All other copyright for the rest of the project are held by [[Richo Han](richo.tw), 2018].
