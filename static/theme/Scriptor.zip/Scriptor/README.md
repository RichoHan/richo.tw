# Scriptor (Modified)

Scriptor is a minimal, clean, modern & responsive Ghost theme for writers, originally forked from [JustGoodThemes/Scriptor](https://github.com/JustGoodThemes/Scriptor).

## Copyright & License

Copyright (c) 2015-2018 Just Good Themes - Released under the [MIT license](LICENSE).